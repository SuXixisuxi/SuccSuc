/**-------------------------------------------------------------------------------------------
** Created by:          qinyx
** Last modified Date:  2014-02-28
** Last Version:        V1.00
** Descriptions:        STM32F407Ƕ��ʽʵ����
**	  Gpio�����ļ�
**
**-------------------------------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "KEY.h"
#include "delay.h"
#include "touch.h"
/******************************************************************************************
*�������ƣ�void KEYGpio_Init(void)
*
*��ڲ�������
*
*���ڲ�������
*
*����˵����KEY��ʼ��
//KEY_S1      PF8
//KEY_S2      PF9
//KEY_S3      PF10
*******************************************************************************************/
void KEYGpio_Init(void)
{    
    GPIO_InitTypeDef  GPIO_InitStructure;
    
    //  KEY_S1  	PF8
	//  KEY_S2      PF9
	//  KEY_S3      PF10
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOF, &GPIO_InitStructure);
}

/**********************************************************************************************************
�������ƣ�����ɨ�躯��
�����������
�����������
�������أ�����ֵ
**********************************************************************************************************/
unsigned char KeyScan(void)
{		 
    unsigned char buf[4] = {0};
    unsigned char temp = 0;
    static u8 key_up=1;
    
    buf[0] = KEY_S1_READ();
    buf[1] = KEY_S2_READ();
		buf[2] = KEY_S3_READ();
    
    if(key_up && (buf[0] == 0 || buf[1] == 0 || buf[2] == 0))
    {
        key_up = 0;
        
        delay_ms(100);
    
        buf[0] = KEY_S1_READ();
		buf[1] = KEY_S2_READ();
		buf[2] = KEY_S3_READ();
        
        //  KEY_S1
        if ( (buf[0] == 0) && (buf[1] == 1) && (buf[2] == 1))
        {
            temp = 1;
        }
        
        //  KEY_S2
        if ( (buf[0] == 1) && (buf[1] == 0) && (buf[2] == 1))
        {
            temp = 2;
        }
		
		//  KEY_S3
        if ( (buf[0] == 1) && (buf[1] == 1) && (buf[2] == 0))
        {
            temp = 3;
        }
    }
    else if (buf[0] == 1 && buf[1] == 1 && buf[2] == 1) key_up = 1;
    
    return temp;
}
//extern _m_tp_dev tp_dev;
//LCD����λ��480x800
unsigned char LCDScan(void)
{		 
    unsigned char buf[16] = {0};
    unsigned char temp = 0;
		u8 i,buflag=0;
    static u8 key_up=1;
		tp_dev.scan(0);
    buf[0] = !(tp_dev.x[0]>10&&tp_dev.x[0]<110&&tp_dev.y[0]>10&&tp_dev.y[0]<190);//1��
    buf[1] = !(tp_dev.x[0]>130&&tp_dev.x[0]<230&&tp_dev.y[0]>10&&tp_dev.y[0]<190);//2��
		buf[2] = !(tp_dev.x[0]>250&&tp_dev.x[0]<350&&tp_dev.y[0]>10&&tp_dev.y[0]<190);//3
    buf[3] = !(tp_dev.x[0]>370&&tp_dev.x[0]<470&&tp_dev.y[0]>10&&tp_dev.y[0]<190);//4

		buf[4] = !(tp_dev.x[0]>10&&tp_dev.x[0]<110&&tp_dev.y[0]>210&&tp_dev.y[0]<390);
		buf[5] = !(tp_dev.x[0]>130&&tp_dev.x[0]<230&&tp_dev.y[0]>210&&tp_dev.y[0]<390);
		buf[6] = !(tp_dev.x[0]>250&&tp_dev.x[0]<350&&tp_dev.y[0]>210&&tp_dev.y[0]<390);
		buf[7] = !(tp_dev.x[0]>370&&tp_dev.x[0]<470&&tp_dev.y[0]>210&&tp_dev.y[0]<390);
		
		buf[8] = !(tp_dev.x[0]>10&&tp_dev.x[0]<110&&tp_dev.y[0]>410&&tp_dev.y[0]<590);
    buf[9] = !(tp_dev.x[0]>130&&tp_dev.x[0]<230&&tp_dev.y[0]>410&&tp_dev.y[0]<590);
		buf[10] = !(tp_dev.x[0]>250&&tp_dev.x[0]<350&&tp_dev.y[0]>410&&tp_dev.y[0]<590);
    buf[11] = !(tp_dev.x[0]>370&&tp_dev.x[0]<470&&tp_dev.y[0]>410&&tp_dev.y[0]<590);
		
		buf[12] = !(tp_dev.x[0]>10&&tp_dev.x[0]<110&&tp_dev.y[0]>610&&tp_dev.y[0]<790);
		buf[13] = !(tp_dev.x[0]>130&&tp_dev.x[0]<230&&tp_dev.y[0]>610&&tp_dev.y[0]<790);
		buf[14] = !(tp_dev.x[0]>250&&tp_dev.x[0]<350&&tp_dev.y[0]>610&&tp_dev.y[0]<790);
		buf[15] = !(tp_dev.x[0]>370&&tp_dev.x[0]<470&&tp_dev.y[0]>610&&tp_dev.y[0]<790);
		
		for(i=0;i<16;i++)if(buf[i]==0){buflag = 1;break;};
    if(key_up && (buflag == 1))
    {
			key_up = 0;
			
			delay_ms(10);
			tp_dev.scan(0);
			buf[0] = !(tp_dev.x[0]>10&&tp_dev.x[0]<110&&tp_dev.y[0]>10&&tp_dev.y[0]<190);//1��
			buf[1] = !(tp_dev.x[0]>130&&tp_dev.x[0]<230&&tp_dev.y[0]>10&&tp_dev.y[0]<190);//2��
			buf[2] = !(tp_dev.x[0]>250&&tp_dev.x[0]<350&&tp_dev.y[0]>10&&tp_dev.y[0]<190);//3
			buf[3] = !(tp_dev.x[0]>370&&tp_dev.x[0]<470&&tp_dev.y[0]>10&&tp_dev.y[0]<190);//4
			
			buf[4] = !(tp_dev.x[0]>10&&tp_dev.x[0]<110&&tp_dev.y[0]>210&&tp_dev.y[0]<390);
			buf[5] = !(tp_dev.x[0]>130&&tp_dev.x[0]<230&&tp_dev.y[0]>210&&tp_dev.y[0]<390);
			buf[6] = !(tp_dev.x[0]>250&&tp_dev.x[0]<350&&tp_dev.y[0]>210&&tp_dev.y[0]<390);
			buf[7] = !(tp_dev.x[0]>370&&tp_dev.x[0]<470&&tp_dev.y[0]>210&&tp_dev.y[0]<390);

			buf[8] = !(tp_dev.x[0]>10&&tp_dev.x[0]<110&&tp_dev.y[0]>410&&tp_dev.y[0]<590);
			buf[9] = !(tp_dev.x[0]>130&&tp_dev.x[0]<230&&tp_dev.y[0]>410&&tp_dev.y[0]<590);
			buf[10] = !(tp_dev.x[0]>250&&tp_dev.x[0]<350&&tp_dev.y[0]>410&&tp_dev.y[0]<590);
			buf[11] = !(tp_dev.x[0]>370&&tp_dev.x[0]<470&&tp_dev.y[0]>410&&tp_dev.y[0]<590);

			buf[12] = !(tp_dev.x[0]>10&&tp_dev.x[0]<110&&tp_dev.y[0]>610&&tp_dev.y[0]<790);
			buf[13] = !(tp_dev.x[0]>130&&tp_dev.x[0]<230&&tp_dev.y[0]>610&&tp_dev.y[0]<790);
			buf[14] = !(tp_dev.x[0]>250&&tp_dev.x[0]<350&&tp_dev.y[0]>610&&tp_dev.y[0]<790);
			buf[15] = !(tp_dev.x[0]>370&&tp_dev.x[0]<470&&tp_dev.y[0]>610&&tp_dev.y[0]<790);
			//  KEY_S1
			if (buf[0] == 0)temp = 1;
			if (buf[1] == 0)temp = 2;
			if (buf[2] == 0)temp = 3;
			if (buf[3] == 0)temp = 4;
			if (buf[4] == 0)temp = 5;
			if (buf[5] == 0)temp = 6;
			if (buf[6] == 0)temp = 7;
			if (buf[7] == 0)temp = 8;
			if (buf[8] == 0)temp = 9;
			if (buf[9] == 0)temp = 10;
			if (buf[10] == 0)temp = 11;
			if (buf[11] == 0)temp = 12;
			if (buf[12] == 0)temp = 13;
			if (buf[13] == 0)temp = 14;
			if (buf[14] == 0)temp = 15;
			if (buf[15] == 0)temp = 16;
				
    }
    else if (buf[0] == 1 && buf[1] == 1 && buf[2] == 1&& (buf[3] == 1)) key_up = 1;
    return temp;
}
