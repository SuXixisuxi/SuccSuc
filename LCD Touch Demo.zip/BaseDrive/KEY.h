#ifndef _KEY_H_
#define _KEY_H_
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "LED.h"
#include "lcd.h"
#include "key.h"
#include "touch.h"
#include "MyCode.h"
#include "PWM.h"
#include "DCMotor.h"
#include "ADC.h"
#include "CH455I2C.h"
#include "servo.h"
#include "KEY.h"
#include "USART2.h"
/*KEY���Ŷ���
//KEY_S1      PF8
//KEY_S2      PF9
//KEY_S3      PF10
*/
#define  	KEY_S1_READ()  	GPIO_ReadInputDataBit(GPIOF, GPIO_Pin_8)
#define  	KEY_S2_READ()  	GPIO_ReadInputDataBit(GPIOF, GPIO_Pin_9)
#define  	KEY_S3_READ()  	GPIO_ReadInputDataBit(GPIOF, GPIO_Pin_10)

void KEYGpio_Init(void);
unsigned char KeyScan(void);
unsigned char LCDScan(void);
#endif
