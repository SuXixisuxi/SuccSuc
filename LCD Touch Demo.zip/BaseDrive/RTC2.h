#ifndef RTC2_H
#define RTC2_H
#include <time.h>
#include <string.h>
#include "stm32f4xx.h"

ErrorStatus RTC_Set_Time(unsigned char hour, unsigned char min, unsigned char sec, unsigned char ampm);
ErrorStatus RTC_Set_Date(u16 year, unsigned char month, unsigned char date, unsigned char week);
unsigned char RTC_Configuration(void);
void RTC_Set_AlarmA(unsigned char week, unsigned char hour, unsigned char min, unsigned char sec);
void RTC_Set_WakeUp(unsigned int wksel, unsigned short cnt);
#endif
