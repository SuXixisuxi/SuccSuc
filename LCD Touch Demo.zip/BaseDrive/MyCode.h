#ifndef __MyCode_H__
#define __MyCode_H__

#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "LED.h"
#include "lcd.h"
#include "key.h"
#include "touch.h"
#include "MyCode.h"
#include "PWM.h"
#include "DCMotor.h"
#include "ADC.h"
#include "CH455I2C.h"
#include "servo.h"
#include "KEY.h"

void Load_Drow_Dialog(void);
void gui_draw_hline(u16 x0, u16 y0, u16 len, u16 color);
void gui_fill_circle(u16 x0, u16 y0, u16 r, u16 color);
u16 my_abs(u16 x1, u16 x2);
void lcd_draw_bline(u16 x1, u16 y1, u16 x2, u16 y2, u8 size, u16 color);
void ctp_test(void);

void Menu_Button(void);
void touch(void);
void LCD_ShowTitle(u16 x,u16 y,u16 size,u8 index,u16 font_color,u16 back_color,u8 mode);	//32*32,48*48,64*64������
void LCD_ShowChinese(u16 x,u16 y,u16 size,u8 index,u16 font_color,u16 back_color,u8 begin,u8 number);
void FangGe(void);
void GetTime(void);
void ShowTime(void);
void ADC_Menu(void);
void JiSuan_Menu(void);
void Suan(void);
void ShowPicture(void);
void DrawTimeFrame(u16 x,u16 y,u16 o,u16 in) ;
void LCD_DrawAngleLine(uint16_t centerX, uint16_t centerY, float angleDegrees, uint16_t radiusOuter, uint16_t radiusInner, uint16_t color);
void LCD_DrawAngleLine2(uint16_t centerX, uint16_t centerY, float angleDegrees, uint16_t radiusOuter, uint16_t radiusInner, uint16_t color);
void Set_Menu(void);
void SetTimes(void);
void DianJi_Menu(void);
void DianJi(void);
void LEDDen(u8 mode);
void NaoZhongMenu(void);
void SetNaoZhong(void);
void NaoZhong(void);
void LEDSHOW(void);
void Picture_SHOW(void);
#endif	







