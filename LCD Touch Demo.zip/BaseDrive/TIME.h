#ifndef _TIME_H_
#define _TIME_H_

void TIM2_Configuration(void);
void EXTI_Config(void);
#endif
