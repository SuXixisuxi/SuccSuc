#ifndef _SERVO_H_
#define _SERVO_H_


#include "stm32f4xx.h"


void TIM1_Configuration(void);
void SetJointAngle(unsigned char angle);

#endif
