#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "LED.h"
#include "lcd.h"
#include "key.h"
#include "touch.h"
#include "MyCode.h"
#include "PWM.h"
#include "DCMotor.h"
#include "ADC.h"
#include "CH455I2C.h"
#include "servo.h"
#include "KEY.h"
#include "USART2.h"
#include "RTC2.h"
#include "TIME.h"
#include "picture.h"
#include "adxl345.h"
#include "BEEP.h"
//lcddev.width = 480;
//lcddev.height = 800;
//��120һ��,��200һ��

RTC_TimeTypeDef RTC_TimeStruct;
RTC_DateTypeDef RTC_DateStruct;
extern u8 lcd_key;
u8 touch_num;
u16 cnt=0;
u8 oneflag,oneflag2;
int main(void)
{

	touch_num=255;
	oneflag=0;												//ÿ���־λ
	oneflag2=0;
	
	SysTick_Init();                 	//  ϵͳ�δ�ʱ����ʼ��    
	LEDGpio_Init();                		//  ��ʼ��LED		
	KEYGpio_Init();

	RTC_Configuration();							//RTCʱ�ӳ�ʼ��

	LCD_Init();												//LCD��ʼ��
	LEDGpio_Init();	
	tp_dev.init();										//��������ʼ��
	POINT_COLOR = RED;          			//������Ϊ��ɫ
	DCMotorGpio_Init();								//�����ʼ��
	Adc_Init();												//ADC��ʼ��
	ADXL345_SPI_Init();								//���ٶ�
	ADXL345_Init();

	TIM2_Configuration();		
	
	
	BEEPGpio_Init();
//		RTC_Set_Date(24, 12, 24, 1);
//		RTC_Set_Time(13,24,43,0);
	Menu_Button();

	if(tp_dev.touchtype & 0X80)
	{
		touch();
	}


}






