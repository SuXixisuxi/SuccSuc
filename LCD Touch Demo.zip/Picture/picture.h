#ifndef PICTURE_H
#define PICTURE_H

extern const unsigned char gImage_picture0[];
extern const unsigned char gImage_picture1[];
extern const unsigned char gImage_picture2[];
extern const unsigned char gImage_picture3[];
extern const unsigned char gImage_picture4[];
extern const unsigned char gImage_picture5[];
extern const unsigned char gImage_picture6[];
extern const unsigned char gImage_picture7[];
#endif
